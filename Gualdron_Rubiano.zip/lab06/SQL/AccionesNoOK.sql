--el nombre del adjetivo no se debe reptir
INSERT INTO ADJETIVO VALUES (3, 'Monitored');