--opiniones
INSERT INTO OPINION VALUES (6, TO_DATE('2003-01-21', 'YYYY-MM-DD'), 'C', 'Morbi  justo.', 'momentos de error', 'mabreheart5@techcrunch.com', 'application');
INSERT INTO OPINION VALUES (7, TO_DATE('2001-01-21', 'YYYY-MM-DD'), 'G', 'In platea.', 'momentos negativos', 'sdagon6@youtu.be', 'NEWIA');
INSERT INTO OPINION VALUES (8, TO_DATE('2002-01-21', 'YYYY-MM-DD'), 'E', 'In hac platea .', 'momentos de error', 'lgoater7@ucoz.com', 'intangible');
INSERT INTO OPINION VALUES (9, TO_DATE('2010-01-21', 'YYYY-MM-DD'), 'G', 'Nulla neque.', 'momentos de error', 'zbatteson8@patch.com', 'real-time');
--adjetivos
INSERT INTO ADJETIVO VALUES (1, 'Switch');
INSERT INTO ADJETIVO VALUES (2, 'Monitored');
